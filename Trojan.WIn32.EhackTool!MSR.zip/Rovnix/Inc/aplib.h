/*
 * aPLib compression library  -  the smaller the better :)
 *
 * COFF format header file
 *
 * Copyright (c) 1998-2009 by Joergen Ibsen / Jibz
 * All Rights Reserved
 *
 * http://www.ibsensoftware.com/
 */

#ifndef APLIB_H_INCLUDED
#define APLIB_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#ifndef APLIB_ERROR
# define APLIB_ERROR (-1)
#endif

unsigned int __cdecl aP_pack(const void *source,
                             void *destination,
                             unsigned int length,
                             void *workmem,
                             int (__cdecl *callback)(unsigned int, unsigned int, unsigned int, void *),
                             void *cbparam);

unsigned int __cdecl aP_workmem_size(unsigned int inputsize);

unsigned int __cdecl aP_max_packed_size(unsigned int inputsize);

unsigned int __cdecl aP_depack_asm(const void *source, void *destination);

unsigned int __cdecl aP_depack_asm_fast(const void *source, void *destination);

unsigned int __cdecl aP_depack_asm_safe(const void *source,
                                        unsigned int srclen,
                                        void *destination,
                                        unsigned int dstlen);

unsigned int __cdecl aP_crc32(const void *source, unsigned int length);

unsigned int __cdecl aPsafe_pack(const void *source,
                                 void *destination,
                                 unsigned int length,
                                 void *workmem,
                                 int (__cdecl *callback)(unsigned int, unsigned int, unsigned int, void *),
                                 void *cbparam);

unsigned int __cdecl aPsafe_check(const void *source);

unsigned int __cdecl aPsafe_get_orig_size(const void *source);

unsigned int __cdecl aPsafe_depack(const void *source,
                                   unsigned int srclen,
                                   void *destination,
                                   unsigned int dstlen);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* APLIB_H_INCLUDED */


#ifndef DEPACK_H_INCLUDED
#define DEPACK_H_INCLUDED

typedef unsigned long CRC32;

#ifdef __cplusplus
extern "C" {
#endif

#ifndef APLIB_ERROR
# define APLIB_ERROR (-1)
#endif

/* function prototype */
unsigned int _stdcall aP_depack(const void *source, void *destination);

#ifdef __cplusplus
} /* extern "C" */
#endif

typedef struct _AP_FILE_HEADER
{
	unsigned long	Tag;
	unsigned long	HeaderSize;
	unsigned long	PackedSize;
	CRC32			PackedCrc;
	unsigned long	OriginalSize;
}AP_FILE_HEADER, *PAP_FILE_HEADER;


#endif /* DEPACK_H_INCLUDED */
