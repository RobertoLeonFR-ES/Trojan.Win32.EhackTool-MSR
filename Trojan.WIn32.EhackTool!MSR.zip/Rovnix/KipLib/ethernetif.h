#ifndef __ETHERNET_F_H_
#define __ETHERNET_F_H_

err_t ethernetif_init(struct netif *netif);

#endif //__ETHERNET_F_H_